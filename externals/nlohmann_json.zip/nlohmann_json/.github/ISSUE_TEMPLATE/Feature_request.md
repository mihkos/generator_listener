---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'kind: enhancement/improvement'
assignees: ''

---

- Describe the feature in as much detail as possible.

- Include sample usage where appropriate.
